import java.util.List; 
import java.util.ArrayList; 

//TODO ABROGATED

/**
 * @date 1 June 2018
 * @author Clayton Marr
 * Class to represent the context of a shift
 * in order to handle phenomena like ()* and ()+, etc.
 */
public class ShiftContextOLD {
	private List<RestrictPhone> placeRestrs; // the restriction on each place as indicated by index 

	private String[] parenInclBySpot;
		//this class variable denotes for each spot according to its index in the placeRestrs,
			// the parenthetical structures it is included in
			// the parenthetical structures involved are the following : 
			// - plain parentheses mean zero or one occurrence of that which is contained 
			// - starred parentheses ( )* -- zero or any number of occurrences of contained segments
			// - plussed parentheses ( )+ -- one or more occurrences of the contained segments. 
			// if there are nested parenthetical structures, then the first one is listed first
			// ... and they are separated by a semicolon <<;>> 
			// the parenthetical structure inclusion is noted by BIEO notation : B- beginning of structure
				// E--end of structure, I- inside structure, O-outside 
				// BP~IP~EP -- in plain parenthesis ; B*~I*~E* -- in starred paren; B+~I+~E+ -- in plussed paren .
	
	
	private boolean pseudosMatter; 
	private int minSize; 

	//constructors -- TODO fix these 
	public ShiftContextOLD(List<RestrictPhone> plrstrs) 
	{	placeRestrs = new ArrayList<RestrictPhone>(plrstrs) ; 
		pseudosMatter = false; 
		parenInclBySpot = null; 
		minSize = plrstrs.size(); 
	}
	
	public ShiftContextOLD(List<RestrictPhone> plrstrs, String[] pibs) 
	{	assert pibs.length == plrstrs.size() : "Error: restrictions array must be same length as parenthesis inclusion array";
		placeRestrs = new ArrayList<RestrictPhone>(plrstrs) ;	
		parenInclBySpot = pibs; 
		pseudosMatter = false; 
		minSize = placeRestrs.size(); 	}
	
	public ShiftContextOLD(List<RestrictPhone> plrstrs, boolean psPhMatter)
	{
		placeRestrs = new ArrayList<RestrictPhone>(plrstrs) ; 
		pseudosMatter = psPhMatter; 
		parenInclBySpot = null; 
		minSize = plrstrs.size(); 
	}
	
	public ShiftContextOLD(List<RestrictPhone> plrstrs, String[] pibs, boolean psPhMatter) 
	{
		assert pibs.length == plrstrs.size() : "Error: restrictions array must be same length as parenthesis inclusion array";
		placeRestrs = new ArrayList<RestrictPhone>(plrstrs) ;
		parenInclBySpot = pibs; 
		pseudosMatter = psPhMatter; 
		minSize = placeRestrs.size();
	}
	
	public int generateMinSize() 
	{
		if (parenInclBySpot.equals(null))	return placeRestrs.size(); 
		int nonParenSpots = 0, prsSize = placeRestrs.size(); 
		for (int i = 0 ; i < prsSize; i++)
			if(parenInclBySpot[i].equals("O"))	nonParenSpots++; 
		return nonParenSpots; 
	}
	
	/**isPriorMatch
	 * checks if a legal prior context can be found in @param phonSeq
	 * if it proceeds @param firstInd, the first index of the possibl
	 * ... targeted segment for a shift
	 * @return true if so, otherwise false. 
	 */
	public boolean isPriorMatch (List<SequentialPhonic> phonSeq, int firstInd)
	{
		if(minSize == 0)	return true; 
		if(minSize > firstInd)	return false; 
		int  currPlaceInCand = firstInd - 1 , currRestrPlace = placeRestrs.size()-1; 
		//TODO note: firstInd is also the maximum size of the possible prior, for obvious reasons-- this is important
			//...because if the postulated prior becomes greater than that size, we will return false. 
			//this is relevant for the method deciding whether to investigate further possibilities due to 
				//... parenthetical disjunctions 
		
		return isPriorMatchHelper(phonSeq, placeRestrs, parenInclBySpot, firstInd, currPlaceInCand, currRestrPlace); 
	}
	
	
	/** isPriorMatchHelper -- recursive helper method for isPriorMatch 
	 * recurses by modifying the proxy variables @param plrestrVersion (proxy modified version of placeRestrs)
	 * and @param plparenVersion (same as above for parenInclBySpot
	 * 
	 * Recursion cases: 
	 * 1) beginning of plrestrVersion reached i.e. crp < 0 : return true 
	 * 2) beginning of phonSeq reached before that i.e. cpic < 0 : return false
	 * 3) at least one paren statement opens at curr-place: 
	 * 		3a) disagreement with restrictions on this place	
	 *			3a1) at least one plussed paren opens here (i.e. 1 or more): return false 
	 *			3a2) else EXCLUDE all paren statements starting here and their contents
	 *		3b) restrictions matched 
	 *			3b1) a nesting level above ends here too : then test first recurse with EXCLUSION of just this paren
	 *					and if that turns out false, then recurse with INCLUSION; in neither case 
	 *					do we increment the counters 
	 *			3b2) else: increment params and test first recursion with EXCLUSION of this paren, and then if that 
	 *				is false, test recursion with INCLUSION. 
	 * 4) while conditions (1), (2) and (3) are not met: 
	 * 		4a) if current place is a pseudophone and pseudos don't matter, increment only currPlaceInCand
	 * 			 and return to beginning of loop
	 * 		4b) if non-match return false
	 * 		4c) if match, increment both currRestrPlace and currPlaceInCand and go to beginning of loop  
	 * 	-- if evver conditiosn (1), (2) or (3) are met in this loop, behave accordingly. 
	 * @return
	 */
	public boolean isPriorMatchHelper(List<SequentialPhonic> phonSeq, List<RestrictPhone> plrestrVersion, 
			String[] plparenVersion, int firstInd, int cpic, int crp)
	{
		if(crp < 0)	return true;
		if(cpic < 0)	return false; 

		String[] nestingsHere = plparenVersion[crp].split(";"); 
		String currNesting = nestingsHere[nestingsHere.length - 1 ];
		
		assert !currNesting.contains("B") && !currNesting.contains("I"): 
			"Error: Found a B or I nesting marker -- as per how this script iterates, these should all be removed before they are reached, "
			+ "so we know something went quite wrong"; 
		
		int currRestrPlace = crp, currPlaceInCand = cpic; 
		
		while(currRestrPlace >= 0 && currPlaceInCand >= 0)
		{
			SequentialPhonic currCandPhon = phonSeq.get(currPlaceInCand);
			if(!pseudosMatter && !currCandPhon.getType().equals("phone"))
				currPlaceInCand--;
			else if(plparenVersion[currRestrPlace].equals("O"))
			{	
				if(plrestrVersion.get(currRestrPlace).compare(currCandPhon)) 
				{	currRestrPlace--; currPlaceInCand--;	}
				else return false;
			}//at this point we know it is included in some type of paren. 
			else 
			{
				if(placeRestrs.get(currRestrPlace).compare(currCandPhon))
				{
					//TODO this 
				}
				else // failure to meet specifications, but this is the last place in a parenthetical structure
				{
					if(currNesting.contains("+"))	return false; //if it's a plus and it failed to occur at all
														//... then this is a fatal failure. 
					//at this point we must assume that all parenthetical structures including this place 
					//are not included if it is to have a chance of being true 
					return isPriorMatchHelperExcludeParensHere(phonSeq, plrestrVersion, plparenVersion, 
							firstInd, currPlaceInCand, currRestrPlace);
				}
			}
			
		}
		if(crp < 0)	return true;
		if(cpic < 0)	return false; 
		
	}
	
	public boolean isPriorMatchHelperOld(List<SequentialPhonic> phonSeq, List<RestrictPhone> plrestrVersion, String[] plparenVersion,
			 int cpic, int crp)
	{
	
		int currPlaceInCand = cpic, currRestrPlace = crp; 
		
		while(currRestrPlace >= 0 && currPlaceInCand >= 0)
		{
			SequentialPhonic currCandPhon = phonSeq.get(currPlaceInCand); 
			if(!pseudosMatter && !currCandPhon.getType().equals("phone")) //if pseudos don't matter and it's a pseudophone, pass over it. 
				currPlaceInCand--;
			else if(plparenVersion[currRestrPlace].equals("O"))
			{	if(plrestrVersion.get(currRestrPlace).compare(currCandPhon))	
				{	currRestrPlace--; currPlaceInCand--; }
				else	return false; 	
			} //at this point we know it is included in some type of paren. 
			else if(placeRestrs.get(currRestrPlace).compare(currCandPhon) == false)
			{
				String parensHere = plparenVersion[currRestrPlace]; 
				if(parensHere.contains("E+"))	return false; 
				//at this point we must assume that all parenthetical structures including this place 
					//are not included. 				
				return isPriorMatchHelperExcludeParensHere(phonSeq, plrestrVersion, plparenVersion, 
						currPlaceInCand, currRestrPlace);
			}
			else // it's in a paren and the match is true. 
			{
				String[] nestingsHere = plparenVersion[currRestrPlace].split(";"); 
				String lowestNesting = nestingsHere[nestingsHere.length - 1 ];
				assert lowestNesting.contains("E"): 
					"Error: the lowest level nesting should be deleted if this is not the end, but a non-end of a nesting detected!"; 
				//because how we are going about this is deciding whether to include or delete 
					// a nesting immediately upon seeing its end
					// so we should never see an I or B marker here. 
				
				//act differently depending on what type of paren(s) is/are here. 
				//within one iteration of this method, we only need to branch on the lowest level nesting
					//if there are multiple nestings beginning at this place
				//how we recurse also is influenced by whether the next nesting up is also an end unit. 
				
				//if simple parenthesis parenthesis : test exclusion and then test deterministic inclusion 
				if(lowestNesting.contains("P"))
				{
					boolean matchWithExclusion = isPriorMatchHelperExclude; //TODO finish this
					if(matchWithExclusion)	return true; 
					else	//include. 
					{
						boolean parenCloseAbove = nestingsHere[nestingsHere.length - 2].contains("E"); 
						//i.e. if there is a closing clause above. 
						
						//remove from the paren list for each affected segment 
						
					}
					
					
				}
				
				
				
			}
			
		}
	}
	
	public boolean isPriorMatchHelperIncludeLowestParenHere (List<SequentialPhonic> phonSeq, List<RestrictPhone> plrestrVersion,
			String[] plparenVersion, int firstInd, int currPlaceInCand, int currRestrPlace)
	{
		//first determine whether there are levels above the current one that open here,
		// and throw an error if the current nestings have values they shouldn't have
		// -- i.e. anything but the E end marker, because of how this class is iterating. 
		String currNestings = plparenVersion[currRestrPlace]; 
		String[] currNestingList = currNestings.split(";"); 
		
		assert (!currNestings.contains("B") && !currNestings.contains("O") && !currNestings.contains("I")): 
			"Error: a non-ending tag detected when helper method for inclusion of parenthetical statements called; "
			+ "this signals a violation of how the prior match checking function is supposed to iterate, meaning an error certainly "
			+ "occurred somewhere.";
		
		//i.e. P for normal paren, + for plussed paren, and * for starred paren. 
		String nestingType = currNestingList[currNestingList.length - 1].substring(1); 
		
		boolean furtherNested = (currNestings.split(";").length > 1 ); 
		
		//find the first index of where this nesting starts-- we will be iterating from the end to hte start to find what to delete. 
		int firstNestingInd = currRestrPlace - 1 , currNestingLevel = currNestings.split(";").length - 1; 
		String nestingOfInterest = plparenVersion[firstNestingInd].split(";")[currNestingLevel]; 
		//assert nestingOfInterest.contains("B") || nestingOfInterest.contains("I") : "Error in order of BIEO nesting marking";
		
		while(nestingOfInterest.charAt(0) != 'B' && firstNestingInd >= 0) 
		{
			assert nestingOfInterest.contains("I") : "Error in order of BIEO nesting marking";
			firstNestingInd--; 
			nestingOfInterest = plparenVersion[firstNestingInd].split(";")[currNestingLevel]; 
		}
		assert firstNestingInd >= 0 : "Error in order of BIEO nesting marking: went before index 0"
				+ "without seeing the beginning of the parenthetical structure" ; 
		
		//now we know firstNestingInd is the beginning index of the parenthetical structure. 
		
		
		//TODO this 
	}
	
	
	//auxiliary method for isPriorMatchHelper (which is itself auxiliary)
	//helps make recursive call of isPriorMatchHelper 
	//...with all parenthetials ending on the current state in the placeRestr list excluded i.e. deleted
	public boolean isPriorMatchHelperExcludeParensHere(List<SequentialPhonic> phonSeq, List<RestrictPhone> plrestrVersion, 
			String[] plparenVersion, int firstInd, int currPlaceInCand, int currRestrPlace)
	{
		String[] eachParenStructRel = plparenVersion[currRestrPlace].split(";"); 
		
		//detect the highest level of nesting that ends at this space 
			/// -- we assume that obviously a higher level nesting cannot start within a lower level nesting that had already previously startd
			// as per the definition of it. 
		int highestNesting = eachParenStructRel.length - 1; 
	
		assert eachParenStructRel[highestNesting].contains("E") : 
			"Error: last index of deleted segment is not hte end of relevant parenthesis for lowest level of nesting";
		
		while(eachParenStructRel[highestNesting].contains("E") && highestNesting >= 0)
			highestNesting--; 
		if(highestNesting == -1)	highestNesting = 0; 
		
		String typeOfHighestNesting = eachParenStructRel[highestNesting].substring(1); 
		
		//since all lower levels will be contained, we only need to deal with the highest level. 
		
		//delete all nestings included
		//and delete all phones in deleted nesting in the new version of phonSeq, 
		// which will be passed to recursion
		
		int firstNestingInd = currRestrPlace - 1 ; 
		String nestingOfInterest = eachParenStructRel[firstNestingInd].split(";")[highestNesting]; 
		
		
		while(firstNestingInd >= 0 && !nestingOfInterest.contains("B") 
				&& nestingOfInterest.substring(1).equalsIgnoreCase(typeOfHighestNesting))
		{	firstNestingInd--; 
			nestingOfInterest = eachParenStructRel[firstNestingInd].split(";")[highestNesting]; 
		}
		firstNestingInd += 1; 
		
		//carry out the deletions on the new versions of hte variables.
		int oldLen = parenInclBySpot.length, lenLoss = currRestrPlace - firstNestingInd + 1 ; 
		String[] newParenBySpotArray = new String[oldLen - lenLoss];
		int ni = 0; 
		while (ni < firstNestingInd)
		{	newParenBySpotArray[ni] = parenInclBySpot[ni]; ni++;	}
		
		int nli = currRestrPlace + 1; 
		while(nli < oldLen) //this should be the same point as when ni hits the length of the new array
		{
			newParenBySpotArray[ni] = parenInclBySpot[nli]; ni++; nli++; 
		}
		
		List<RestrictPhone> newRestrPlaces = new ArrayList<RestrictPhone>(); 
		if(firstNestingInd > 0)
			newRestrPlaces.addAll(plrestrVersion.subList(0, firstNestingInd)); 
		if(currRestrPlace + 1 < oldLen)
			newRestrPlaces.addAll(plrestrVersion.subList(currRestrPlace+1, oldLen));

		return isPriorMatchHelper(phonSeq, newRestrPlaces, newParenBySpotArray, 
				firstInd, currPlaceInCand, currRestrPlace - lenLoss);

	}
	
	//auxiliary method for isPrior
	//used to test if the contents of a parenthetical statement match a certain window for only one iteration 
	// assuming there are no nested parenthetical statements 
		//(we assume they have been deparenthesized if they existed previously by the time this is called)
	// return -1 if non-match 
	// else return the first index of the matching window. 
	public int firstIndOfMatchingWindow (List<SequentialPhonic> phonSeq, int segLastInd, List<RestrictPhone> theSeg)
	{
		int segSize = theSeg.size(), phonSeqLen = phonSeq.size(); 
		assert segSize > 0: "Error : attempt to check segment of non-positive length ";
		if(segSize > segLastInd + 1)	return -1; 
		if(theSeg.get(segSize - 1).compare(phonSeq.get(phonSeqLen - 1)) == false)	return -1; 
		else if (segSize == 1)	return segLastInd - 1;
		int segI = segSize - 2 , phSeqI = phonSeqLen - 2; 
		while(segI >= 0 && phSeqI >= 0)
		{
			RestrictPhone currSpecs = theSeg.get(segI);
			SequentialPhonic currCandUnit = phonSeq.get(phSeqI); 
			if(!pseudosMatter && currCandUnit.getType().equals("phone") == false)
				phSeqI--; 
			else if(currSpecs.compare(currCandUnit))
			{	phSeqI--; segI--; }
			else	return -1; 
		}
		if(segI < 0)	return phSeqI + 1; 
		return -1; 
	}
	//TODO fix this shit so it can check a potential context 
	
	
}
